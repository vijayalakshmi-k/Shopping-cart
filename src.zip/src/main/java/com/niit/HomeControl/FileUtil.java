package com.niit.HomeControl;





public class FileUtil {
	//COMMON FUNCTIONALITIES ARE PUT HERE.. LIKE comma problems etc.
	
		public static String removeComma(String name){
			//REPLACE , WITH <EMPTYSPACE>
			return name.replace(",", "");
		}
		
		/*public static void main(String[] args) {
			System.out.println(Util.removeComma(",PRD001"));
		}*/
	}
	
