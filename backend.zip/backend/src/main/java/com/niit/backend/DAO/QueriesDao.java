package com.niit.backend.DAO;

import com.niit.backend.model.Queries;

public interface QueriesDao {
	void addQuery(Queries queries);
}
