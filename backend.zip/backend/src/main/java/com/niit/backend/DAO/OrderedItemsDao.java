package com.niit.backend.DAO;

public class OrderedItemsDao {

}
